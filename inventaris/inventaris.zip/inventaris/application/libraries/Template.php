<?php
class Template {
	protected $_ci;
	function __construct()
	{
		$this->_ci =&get_instance();
	}

	function Admin($template,$data=null)
	{
		$data['content']=$this->_ci->load->view($template,$data, TRUE);
		$data['source']=$this->_ci->load->view('admin/source',$data, TRUE);		
		$this->_ci->load->view('admin/nav',$data);
	}

}
