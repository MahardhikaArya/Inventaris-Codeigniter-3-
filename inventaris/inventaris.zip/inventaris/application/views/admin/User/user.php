  <div class="panel-header panel-header-sm">
    </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title float-left">Daftar User</h4>
                <button class="btn btn-primary float-right" onclick="NewUser();">New User</button>
              </div>
              <?php 
                if ($this->session->flashdata('alert')) {
                  echo"<div class='alert alert-success'>";
                  echo $this->session->flashdata('alert');
                  echo"</div>";
                }
               ?>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class="text-primary">
                      <th>#</th>
                      <th>Nama</th>
                      <th>Username</th>
                      <th>Jenis Kelamin</th>
                      <th>Akses</th>
                      <th>Alamat User</th>
                      <th class="text-right">
                        Action
                      </th>
                    </thead>
                    <tbody>
                      <?php $i=1; foreach ($user as $key) :?>
                      <tr>
                          <td><?=$i++;?></td>
                          <td><?= $key->nama;?></td>
                          <td><?= $key->username;?></td>
                          <td><?= $key->jenis_kelamin;?></td>
                          <td><?= $key->level;?></td>
                          <td><?= substr($key->alamat, 0, 20);?>....</td>
                          <td class="text-right">
                            <a href="<?= base_url('index.php');?>/chat/admin_reply/<?= $key->id;?>" title="Chat User">
                             <button type="button" rel="tooltip" class="btn btn-info btn-sm btn-icon">
                                <i class="now-ui-icons ui-2_chat-round"></i>
                            </button>
                            </a>

                            <a href="<?= base_url('index.php');?>/User/read_more/<?= $key->id;?>" title="Read more">
                             <button type="button" rel="tooltip" class="btn btn-info btn-sm btn-icon">
                                <i class="now-ui-icons ui-1_zoom-bold"></i>
                            </button>
                            </a>

                            <a href="<?= base_url('index.php');?>/User/update_barang/<?= $key->id;?>" title="Update User">
                            <button type="button" rel="tooltip" class="btn btn-success btn-sm btn-icon">
                                <i class="now-ui-icons ui-2_settings-90"></i>
                            </button>
                            </a>
                            
                            <a href="<?= base_url('index.php');?>/User/delete/<?= $key->id;?>" title="Delete User" onclick="return confirm('CONFRM ?');">
                            <button type="button" rel="tooltip" class="btn btn-danger btn-sm btn-icon">
                                <i class="now-ui-icons ui-1_simple-remove"></i>
                            </button>
                            </a>

                          </td>
                      </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
    <div class="modal fade" id="modal_form" role="dialog">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Tambah User</h4>              
              <button class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body form">
             <form method="post" role="form" id="form" enctype="multipart/form-data">
                  <input type="text" name="id" hidden="" class="form-control">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Password</label>
                        <input type="text" name="password" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="form-control">
                          <option value="">--Pilih Level--</option>
                          <option value="laki-laki">Laki-Laki</option>
                          <option value="perempuan">Perempuan</option>
                        </select>
                      </div>
                    </div>                    
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Level</label>
                        <select name="level" class="form-control">
                          <option value="">-Pilih Level-</option>
                          <option value="user">User Permission</option>
                          <option value="admin">Admin Permission</option>
                        </select>
                      </div>
                    </div>
                </form>
            <div class="modal-footer">
              <button class="btn btn-default" data-dismiss="modal">Close</button>
              <button class="btn btn-success" onclick="save();" name="submit" value="Submit">Save Data</button>
            </div>
          </div>
        </div>  
      </div>
        </div>
      </div>
      <script type="text/javascript">
        var save_method;
        var table;
        
        function NewUser(){
          save_method = 'add';
          $('#form')[0].reset();
          $('#modal_form').modal('show');
        }

        function save(){
          var url;
          if (save_method == 'add') {
            url = '<?= base_url('index.php/User/add_user');?>';
          }else{
            url = '<?= base_url('index.php/User/add_user');?>';
          }
          
          $.ajax({
            url       : url,
            type      : "POST",
            data      : $('#form').serialize(),
            dataType  : "JSON",
            success   : function(data){
              $('#modal_form').modal('hide');
              location.reload();
            },
            error     : function(jqXHR, testStatus, errorThrown){
              alert('gagal menambahkan')
            }
          })

        }

      </script>