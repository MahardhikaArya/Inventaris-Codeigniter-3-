  <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h5 class="title">Tambah Admin</h5>
              </div>
              <div class="card-body">
                <form method="post" role="form" enctype="multipart/form-data">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Password</label>
                        <input type="text" name="password" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="form-control">
                          <option value="">--Pilih Level--</option>
                          <option value="laki-laki">Laki-Laki</option>
                          <option value="perempuan">Perempuan</option>
                        </select>
                      </div>
                    </div>                    
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Level</label>
                        <select name="level" class="form-control">
                          <option value="">-Pilih Level-</option>
                          <option value="user">User Permission</option>
                          <option value="admin">Admin Permission</option>
                        </select>
                      </div>
                    </div>
                  <button name="submit" value="Submit" class="btn btn-warning col-md-10" style="margin-left: 8%;">SIMPAN DATA</button>
                </form>
              </div>
            </div>
          </div>        
        </div>
      </div>
