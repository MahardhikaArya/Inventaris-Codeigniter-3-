  <div class="panel-header panel-header-sm">
    </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title float-left">Daftar Admin MBinventaris</h4>
              </div>
              <?php 
                if ($this->session->flashdata('alert')) {
                  echo"<div class='alert alert-success'>";
                  echo $this->session->flashdata('alert');
                  echo"</div>";
                }
               ?>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class="text-primary">
                      <th>#</th>
                      <th>Kirim pesan</th>
                      <th>Nama</th>
                      <th>Username</th>
                      <th>Jenis Kelamin</th>
                      <th>Alamat User</th>
                    </thead>
                    <tbody>
                      <?php $i=1; foreach ($admin as $key) :?>                      
    	                  <tr>
		                      <td><?=$i++;?></td>
		                  	  <td>
		                  	  	<a title="Kirim ke <?= $key->nama;?>" class="btn btn-primary" href="<?= base_url('index.php');?>/chat/admin_message/<?= $key->id;?>">
			                  	<i class="fa fa-edit"></i>
							  </a>
		                  	  </td>
		                      <td><?= $key->nama;?></td>
		                      <td><?= $key->username;?></td>
		                      <td><?= $key->jenis_kelamin;?></td>
		                      <td><?= substr($key->alamat, 0, 20);?>....</td>
		                  </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>