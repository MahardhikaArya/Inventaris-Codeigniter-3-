  <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h5 class="title">Admin Contact</h5>
              </div>
              <div class="card-body">     
                <?php foreach ($pertama->result() as $key ) :?>                
                  <div class="alert alert-danger col-md-5">
                    <p><?= $key->send_by; ?></p>                    
                    <p><?= $key->pesan;?></p>
                    <p><?= substr($key->time, 10 ,12);?></p>
                  </div>
                <?php endforeach; ?>

                <?php foreach ($kedua->result() as $key ) :?>                
                  <div class="alert alert-success col-md-5">                    
                    <p><?= $key->send_by; ?></p>
                    <p><?= $key->pesan; ?></p>
                    <p><?= substr($key->time, 10 ,12);?></p>
                  </div>
                <?php endforeach; ?>
                
                <form method="post" id="form" role="form" enctype="multipart/form-data">
                  <div class="row">

                    <div class="col-md-2" hidden="">
                      <div class="form-group">
                        <input type="text" name="send_to" value="<?= $send_to;?>" class="form-control">
                      </div>
                    </div>                  

                    <div class="col-md-2" hidden="">
                      <div class="form-group">
                        <input type="text" name="send_by" value="<?= $send_by;?>" class="form-control">
                      </div>
                    </div>

                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Isi Pesan</label>
                        <textarea rows="4" required="" type="input" name="pesan"  cols="80" class="form-control"></textarea>
                      </div>
                    </div>
                  </div>
                  <button name="submit" value="Submit" class="btn btn-warning col-md-12">Kirim Pesan</button>
                </form>
              </div>
            </div>
          </div>        
        </div>
      </div>

<script type="text/javascript">
  $.ajax({
    url      : url, 
    type     : "POST",
    data     : $('#form').serialize(),
    dataType : "JSON",
    success  : function(data){
      location.reload()
    }
  })
</script>