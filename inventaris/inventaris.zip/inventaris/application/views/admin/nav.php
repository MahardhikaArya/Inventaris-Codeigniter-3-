<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?= base_url();?>/admin_assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="<?= base_url();?>/admin_assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Inventaris 
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <?= $source;?>
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="orange">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="#" class="simple-text logo-mini">
          MB
        </a>
        <a href="#" class="simple-text logo-normal">
          Inventaris
        </a>
      </div>

      <div class="sidebar-wrapper" id="sidebar-wrapper">
        <ul class="nav">
          <li>
            <a href="<?= base_url('index.php');?>/dashboard">
              <i class="now-ui-icons design_app"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php');?>/Barang">
              <i class="now-ui-icons files_box"></i>
              <p>Daftar Barang</p>
            </a>
          </li>
          
          <?php if ($this->session->userdata('level')== 'admin') : ?>
          <li>
            <a href="<?= base_url('index.php');?>/user">
              <i class="now-ui-icons users_single-02"></i>
              <p>daftar pengguna</p>
            </a>
          </li>
          <?php elseif ($this->session->userdata('level') == 'user') : ?>
          <li>
            <a href="<?= base_url('index.php');?>/Chat">
              <i class="now-ui-icons users_single-02"></i>
              <p>hubungi admin</p>
            </a>
          </li>          
          <?php endif; ?>

          <li>
            <a href="<?= base_url('index.php');?>/admin/bangunan" id="nav">
              <i class="now-ui-icons business_bank"></i>
              <p>daftar bangunan</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php');?>/admin/kendaraan" id="nav">
              <i class="now-ui-icons transportation_bus-front-12"></i>
              <p>daftar kendaraan</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php');?>/admin/lokasi">
              <i class="now-ui-icons location_pin"></i>
              <p>lokasi</p>
            </a>
          </li>
          
          <li>
            <a href="<?= base_url('index.php');?>/admin/mutasi">
              <i class="now-ui-icons design-2_ruler-pencil"></i>
              <p>Mutasi</p>
            </a>
          </li>
          <li class="active-pro">
            <a href="<?= base_url('index.php');?>/login/logout">
              <i class="now-ui-icons sport_user-run"></i>
              <p>LOgout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel" id="main-panel">

      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="<? base_url('index.php');?>/admin">MB INVENTARIS</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form>
              <div class="input-group no-border">
                <input type="text" value="" class="form-control" placeholder="Search...">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <i class="now-ui-icons ui-1_zoom-bold"></i>
                  </div>
                </div>
              </div>
            </form>
            <ul class="navbar-nav">

              <li class="nav-item">
                <?php if ($this->session->userdata('level')== 'admin') : ?>               
                <a class="nav-link" href="<?= base_url('index.php');?>/user">
                  <i class="now-ui-icons media-2_sound-wave"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Stats</span>
                  </p>
                </a>
                <?php elseif ($this->session->userdata('level') == 'user') : ?>
                <a class="nav-link" title="Contact Admin" href="<?= base_url('index.php');?>/dashboard/admin_message">
                  <i class="now-ui-icons phone"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Stats</span>
                  </p>
                </a>

                <?php endif; ?>
              </li>

              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="now-ui-icons users_single-02"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="<?= base_url('index.php');?>/profile">Profile</a>
                  <a class="dropdown-item" href="#">Change Password</a>
                  <a class="dropdown-item" href="#">Logout</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
     <!-- End Navbar -->
     <?= $content;?>      
    <footer class="footer">
        <div class="container-fluid">
          <nav>
            <ul>
              <li>
                <a href="mailto:mahardhika.arya.b@gmail.com?Subject=Hello%20MB%20Inventaris" target="_top">
                  Mahardhika
                </a>
              </li>
              <li>
                <a href="http://presentation.creative-tim.com">
                  About Us
                </a>
              </li>
              <li>
                <a href="http://blog.creative-tim.com">
                  Blog
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright" id="copyright">
            &copy;
            <script>
              document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
            </script>, Designed by
            <a href="https://www.invisionapp.com" target="_blank">Invision</a>. Coded by
            <a href="mailto:mahardhika.arya.b@gmail.com?Subject=Hello%20MB%20Inventaris" target="_top">Mahardhika</a>.
          </div>
        </div>
      </footer>
    </div>
  </div>

</body>

</html>
