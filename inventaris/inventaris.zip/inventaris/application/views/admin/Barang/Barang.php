  <div class="panel-header panel-header-sm">
    </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title float-left">Daftar Barang</h4>
                <a href="<?= base_url('index.php');?>/Barang/tambah_barang" class="btn btn-primary float-right">Tambah Barang</a>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class="text-primary">
                      <th>#</th>
                      <th>Nama</th>
                      <th>Inventaris</th>
                      <th>Letak</th>
                      <th>Status</th>
                      <th>Bahan</th>
                      <th>Harga</th>
                      <th class="text-right">
                        Action
                      </th>
                    </thead>
                    <tbody>
                      <?php $i=1; foreach ($barang as $key) :?>
                      <tr>
                        <td><?=$i++;?></td>
                          <td><?= $key->nama;?></td>
                          <td><?= $key->inventaris;?></td>
                          <td><?= $key->letak;?></td>
                          <td><?= $key->status;?></td>
                          <td><?= $key->bahan;?></td>
                          <td><?= 'Rp. ',$key->harga;?></td>
                          <td class="text-right">
                            <a href="<?= base_url('index.php');?>/Barang/read_more/<?= $key->id;?>">
                             <button type="button" rel="tooltip" class="btn btn-info btn-sm btn-icon">
                                <i class="now-ui-icons ui-1_zoom-bold"></i>
                            </button>
                            </a>

                            <a href="<?= base_url('index.php');?>/Barang/update_barang/<?= $key->id;?>">
                            <button type="button" rel="tooltip" class="btn btn-success btn-sm btn-icon">
                                <i class="now-ui-icons ui-2_settings-90"></i>
                            </button>
                            </a>
                            
                            <a href="<?= base_url('index.php');?>/Barang/delete/<?= $key->id;?>" onclick="return confirm('CONFRM ?');">
                            <button type="button" rel="tooltip" class="btn btn-danger btn-sm btn-icon">
                                <i class="now-ui-icons ui-1_simple-remove"></i>
                            </button>
                            </a>

                          </td>
                      </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>