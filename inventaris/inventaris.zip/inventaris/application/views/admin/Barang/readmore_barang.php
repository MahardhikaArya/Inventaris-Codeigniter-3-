  <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h5 class="title"><?= $nama;  ?></h5>
              </div>
              <div class="card-body">
                <form method="post">
                  <div class="row">
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Inventaris</label>
                        <input type="text" name="inventaris" class="form-control" disabled="" placeholder="Company" value="<?= $inventaris;  ?>">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Letak</label>
                        <input type="text" name="letak" class="form-control" placeholder="Username" value="<?= $letak;  ?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Merek</label>
                        <input type="email" name="merek" class="form-control" placeholder="Email" value="<?= $merek;?>" disabled="">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Asal</label>
                        <input type="text" name="asal" class="form-control" placeholder="Company" value="<?= $asal;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Status</label>
                        <input type="text" name="status" class="form-control" placeholder="Last Name" value="<?= $status;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Bahan</label>
                        <input type="text" name="bahan" class="form-control" placeholder="Last Name" value="<?= $bahan;?>" disabled="">
                      </div>
                    </div>                    
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Satuan</label>
                        <input type="text" name="satuan" class="form-control" placeholder="<?= $satuan;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Ukuran</label>
                        <input type="text" name="ukuran" class="form-control" placeholder="<?= $ukuran;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Tahun</label>
                        <input type="text" name="tahun" class="form-control" placeholder="<?= $tahun;?>" disabled="">
                      </div>
                    </div>                                        
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Jumlah</label>
                        <input type="text" name="jumlah" class="form-control" placeholder="<?= $jumlah;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Harga</label>
                        <input type="number" name="harga" class="form-control" placeholder="" disabled=""value="<?= $harga;?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Keterangan</label>
                        <textarea rows="4" type="input" name="ket" disabled="" cols="80" class="form-control" ><?= $ket; ?></textarea>
                      </div>
                    </div>
                  </div>
                  <a href="<?= base_url('index.php');?>/Barang/update_barang/<?= $id;?>" class="btn btn-primary col-md-12">UPDATE ?</a>
                </form>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card card-user">
              <div>
                <img src="<?= base_url();?>assets/upload/<?= $gambar;?>" alt="">
              </div>
                <div class="button-container">
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-facebook-f"></i>
                </button>
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-twitter"></i>
                </button>
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-google-plus-g"></i>
                </button>
              </div>
            </div>
          </div>
        
        </div>
      </div>