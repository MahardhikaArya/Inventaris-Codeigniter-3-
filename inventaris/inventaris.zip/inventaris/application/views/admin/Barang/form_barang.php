  <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h5 class="title"><?= $header;  ?></h5>
              </div>
              <div class="card-body">
                <form method="post" role="form" enctype="multipart/form-data">

                  <div class="row">
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Nama</label>
                        <input type="text" required="" name="nama" class="form-control" value="<?= $nama;?>">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Inventaris | <span onclick="add_inventaris()" style="color: orange;">*Tambah Inventaris</span></label>
                        <select required="" class="form-control" name="inventaris">
                        <option value="">
                            <?php 
                              if($letak > 1){
                                echo "<?= $inventaris;?>";
                              }else{
                                echo "-";
                              }
                            ?>
                          </option>
                          <?php foreach ($drop as $key ):?>                           
                           <option value="<?= $key->jenis;?>"><?= $key->jenis;?></option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>letak</label>
                        <select required="" class="form-control" name="letak">
                        <option value="">
                            <?php 
                              if($letak > 1){
                                echo "<?= $letak;?>";
                              }else{
                                echo "-";
                              }
                            ?>
                          </option>
                          <?php foreach ($drop1 as $key ):?>                           
                           <option value="<?= $key->nama;?>"><?= $key->nama;?></option>
                          <?php endforeach; ?>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Status</label>
                         <select name="status" required="" class="form-control">
                          <option value="">
                            <?php 
                              if($status > 1){
                                echo "<?= $status;?>";
                              }else{
                                echo "-";
                              }
                            ?>
                          </option>
                          <?php foreach ($drop2 as $key ):?>
                           <option value="<?= $key->nama;?>"><?= $key->nama;?></option>  
                          <?php endforeach; ?>
                         </select>
                      </div>
                    </div>                    
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Merek</label>
                         <select name="merek" required="" class="form-control">
                          <option value="">
                            <?php 
                              if($status > 1){
                                echo "<?= $merek;?>";
                              }else{
                                echo "-";
                              }
                            ?>
                          </option>
                          <?php foreach ($drop3 as $key ):?>
                           <option value="<?= $key->nama;?>"><?= $key->nama;?></option>  
                          <?php endforeach; ?>
                         </select>
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Asal</label>
                        <input type="text" required="" name="asal" class="form-control" value="<?= $asal;?>" >
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Bahan</label>
                        <input type="text" required="" name="bahan" class="form-control" value="<?= $bahan;?>" >
                      </div>
                    </div>                    
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Satuan</label>
                        <select name="satuan" required="" class="form-control">
                          <option value="">
                            <?php 
                              if($status > 1){
                                echo "<?= $satuan;?>";
                              }else{
                                echo "-";
                              }
                            ?>
                          </option>
                          <?php foreach ($drop4 as $key ):?>
                           <option value="<?= $key->nama;?>"><?= $key->nama;?></option>  
                          <?php endforeach; ?>
                         </select>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Ukuran</label>
                        <input type="text" name="ukuran" class="form-control" value="<?= $ukuran;?>" >
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Tahun</label>
                        <input type="date" required="" name="tahun" class="form-control" value="<?= $tahun;?>" >
                      </div>
                    </div>                                        
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Jumlah</label>
                        <input type="number" required="number" name="jumlah" class="form-control" value="<?= $jumlah;?>" >
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Harga</label>
                        <input type="number" required="" name="harga" class="form-control" value="<?= $harga;?>">
                      </div>
                    </div>
                  </div>
                  
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <img id="image-preview" alt="image preview" src="<?= base_url();?>/assets/upload/<?= $gambar;?>">
                        <label name="gambar" class="btn btn-warning" style="color:white;">Pilih Gambar</label>
                        <input type="file" required="" name="gambar" id="image-source" onchange="previewImage();">
                      </div>
                      </div>
                  </div>

                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Keterangan</label>
                        <textarea rows="4" required="" type="input" name="ket"  cols="80" class="form-control"><?= $ket; ?></textarea>
                      </div>
                    </div>
                  </div>
                  <button name="submit" value="Submit" class="btn btn-warning col-md-12">SIMPAN DATA</button>
                </form>
              </div>
            </div>
          </div>        
        </div>

      <div class="modal fade" id="modal_form" role="dialog">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Tambah Pilihan</h4>              
              <button class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body form">
              <form action="#" action="post" id="form">
                <input type="input" hidden="" name="id">
                <div class="form-body">
                  <input type="input" name="jenis" class="form-control" placeholder="Masukan Data Yang Akan Di tambah" style="height: 45px;">
                  </div>
              </form>              
            <div class="modal-footer">
              <button class="btn btn-default" data-dismiss="modal">Close</button>
              <button class="btn btn-success" name="" value="" onclick="saveInventaris();">Save Data</button>
            </div>
          </div>
        </div>  
      </div>
      
      </div>

<script type="text/javascript">

var save_method;
var table;

function add_inventaris(){
  save_method = 'add';
  $('#form')[0].reset();
  $('#modal_form').modal('show');
}


function saveInventaris(){
var url;
if (save_method == 'add') {
  url = "<?= base_url('index.php/Barang/add_inventaris');?>";
}else{
  url = "<?= base_url('index.php/Barang/add_inventaris');?>";
}
  $.ajax({
    url      : url,
    type     : "POST",
    data     : $('#form').serialize(),
    dataType : "JSON",
    success : function(data){
      $('#modal_form').show('hide');
      location.reload();
    }
  })
}

function previewImage() {
    document.getElementById("image-preview").style.display = "block";
    var oFReader = new FileReader();
     oFReader.readAsDataURL(document.getElementById("image-source").files[0]);

    oFReader.onload = function(oFREvent) {
      document.getElementById("image-preview").src = oFREvent.target.result;
    };
  };  
</script>
