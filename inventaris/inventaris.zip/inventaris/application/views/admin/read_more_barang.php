  <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-8">
            <div class="card">
              <div class="card-header">
                <h5 class="title"><?= $nama;  ?></h5>
              </div>
              <div class="card-body">
                <form>
                  <div class="row">
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Inventaris</label>
                        <input type="text" class="form-control" disabled="" placeholder="Company" value="<?= $inventaris;  ?>">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Letak</label>
                        <input type="text" class="form-control" placeholder="Username" value="<?= $letak;  ?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Merek</label>
                        <input type="email" class="form-control" placeholder="Email" value="<?= $merek;?>" disabled="">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Asal</label>
                        <input type="text" class="form-control" placeholder="Company" value="<?= $asal;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Status</label>
                        <input type="text" class="form-control" placeholder="Last Name" value="<?= $status;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="form-group">
                        <label>Bahan</label>
                        <input type="text" class="form-control" placeholder="Last Name" value="<?= $bahan;?>" disabled="">
                      </div>
                    </div>                    
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Satuan</label>
                        <input type="text" class="form-control" placeholder="<?= $satuan;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Ukuran</label>
                        <input type="text" class="form-control" placeholder="<?= $ukuran;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <label>Tahun</label>
                        <input type="text" class="form-control" placeholder="<?= $tahun;?>" disabled="">
                      </div>
                    </div>                                        
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Jumlah</label>
                        <input type="text" class="form-control" placeholder="<?= $jumlah;?>" disabled="">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Harga</label>
                        <input type="text" class="form-control" placeholder="" disabled=""value="<?= $harga;?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Keterangan</label>
                        <textarea rows="4" disabled="" cols="80" class="form-control" ><?= $ket; ?></textarea>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="card card-user">
              <div>
                <img src="<?= base_url();?>assets/upload/<?= $gambar;?>" alt="">
              </div>
                <div class="button-container">
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-facebook-f"></i>
                </button>
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-twitter"></i>
                </button>
                <button href="#" class="btn btn-neutral btn-icon btn-round btn-lg">
                  <i class="fab fa-google-plus-g"></i>
                </button>
              </div>
            </div>
          </div>
        
        </div>
      </div>