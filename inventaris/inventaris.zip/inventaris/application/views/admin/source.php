  <!--     Fonts and icons     -->
  <!--   <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous"> -->

  <!-- CSS Files -->
  <link href="<?= base_url();?>/admin_assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?= base_url();?>/admin_assets/css/now-ui-dashboard.css?v=1.3.0" rel="stylesheet" />

  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?= base_url();?>/admin_assets/demo/demo.css" rel="stylesheet" />

  <!--   Core JS Files   -->
  <script src="<?= base_url();?>/admin_assets/js/core/jquery.min.js"></script>
  <script src="<?= base_url();?>/admin_assets/js/core/popper.min.js"></script>
  <script src="<?= base_url();?>/admin_assets/js/core/bootstrap.min.js"></script>
  <script src="<?= base_url();?>/admin_assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>

  <!-- Chart JS -->
  <script src="<?= base_url();?>/admin_assets/js/plugins/chartjs.min.js"></script>

  <!-- Jquery -->
<!--   <script src="<?= base_url();?>/admin_assets/js/jquery/jquery-3.3.1.js"></script>
 -->
  <!--  Notifications Plugin    -->
  <script src="<?= base_url();?>/admin_assets/js/plugins/bootstrap-notify.js"></script>

  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?= base_url();?>/admin_assets/js/now-ui-dashboard.min.js?v=1.3.0" type="text/javascript"></script>

  <!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->

  <script src="<?= base_url();?>/admin_assets/demo/demo.js"></script>

  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
