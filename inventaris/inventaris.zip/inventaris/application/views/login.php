      <div class="panel-header panel-header-sm">
      </div>
      <div class="content" style="margin-top:-50px;">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto col-sm-9 col-xs-12">
            <div class="card card-upgrade">
              <div class="card-header text-center">
                <h4 class="card-title">Login Page | MB Inventaris</h3>
                  <p class="card-category">
                  Untuk dapat menggunakan layanan inventaris ini anda di persilahkan untuk melakukan login terlebih dahulu.</p>
              </div>
              <div class="card-body">
                <?php 
                    if ($this->session->flashdata('alert')) {
                        echo '<div class="alert alert-warning">';
                        echo $this->session->flashdata('alert');
                        echo '</div>';  
                    } 
                    if ($this->session->flashdata('alert2')) {
                        echo '<div class="alert alert-danger">';
                        echo $this->session->flashdata('alert2');
                        echo '</div>';  
                    }
                    if ($this->session->flashdata('daftar')) {
                        echo $this->session->flashdata('daftar');
                    }
                  ?> 
                  <script type="text/javascript">
                    var get = document.getElementsById('sukses');
                    window.alert("akun berhasil ditambahkan");
                  </script>
                <div class="table-responsive table-upgrade">
                <form method="post" style="margin-left: 25%;">                    
                    <div class="col-md-8 col-sm-9 col-xs-12">
                      <div class="form-group">
                        <label>Nama / Username</label>
                        <input type="text" name="username" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-8 col-sm-9 col-xs-12">
                      <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" >
                      </div>
                    </div>
                    <hr style="margin-left:10%;" class="col-md-5 col-sm-2">
                    <div class="">                     
                      <button name="submit" value="Submit" class="col-md-8 col-sm-9 col-xs-12 btn btn-round btn-primary">Login</button>
                    </div>
                    <a href="<?= base_url('index.php');?>/login/signup">Daftar</a>
                </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

        <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <!-- CSS Files -->
  <link href="<?= base_url();?>/admin_assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?= base_url();?>/admin_assets/css/now-ui-dashboard.css?v=1.3.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?= base_url();?>/admin_assets/demo/demo.css" rel="stylesheet" />
  <!--   Core JS Files   -->
  <script src="<?= base_url();?>/admin_assets/js/core/jquery.min.js"></script>
  <script src="<?= base_url();?>/admin_assets/js/core/popper.min.js"></script>
  <script src="<?= base_url();?>/admin_assets/js/core/bootstrap.min.js"></script>
  <script src="<?= base_url();?>/admin_assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="<?= base_url();?>/admin_assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="<?= base_url();?>/admin_assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?= base_url();?>/admin_assets/js/now-ui-dashboard.min.js?v=1.3.0" type="text/javascript"></script>
  <!-- Now Ui Dashboard DEMO methods, don't include it in your project! -->
  <script src="<?= base_url();?>/admin_assets/demo/demo.js"></script>

  <script type="text/javascript">
    $alert('.alert.').alert();.delay(2000).slideUp('slow');
  </script>