<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MB extends CI_Model {
	function __construct(){
		parent::__construct();

	}
	
	// menampilkan data
	function get_pesan($table, $where1, $where2){
		$this->db->from($table);
		$this->db->where($where1);
		$this->db->where($where2);
		return $this->db->get();
	}

	// send to
	function send_to($table){
		$this->db->from($table);
		$this->db->where("level ","admin");
		$query = $this->db->get();
		return $query->result();
	}

	// validasi user apakah sudah login
	function cek(){
		if ($this->session->userdata('login') == FALSE) {
			redirect('login');
		}
	}

	// PRivate Function

	function get_where_barang($table, $where){
		$this->db->from($table);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result();
	}

	function get_admin($table){
		$this->db->from($table);
		$this->db->where('level','admin');
		$query = $this->db->get();
		return $query->result();
	}

	function get_user($table){
		$this->db->from($table);
		$this->db->where('level','user');
		$query = $this->db->get();
		return $query->result();
	}

	function get_where_adRep($table, $where){
		$this->db->from($table);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result();
	}


	// Function Global 
	function get_all($table){
		$this->db->from($table);
		$query =  $this->db->get();
		return $query->result();
	}

	function insert($table, $data){
		$this->db->insert($table, $data);
	}

	function update($table, $where, $data){
		$this->db->update($table, $where, $data);
	}

	function get_where($table, $where){
		$this->db->from($table);
		$this->db->where($where);
		return $this->db->get();
	}

	function get_where_login($table, $where){
		$this->db->from($table);
		$this->db->where($where);
		return $this->db->get();
		
	}
	
	function delete($table, $where){
		$this->db->where($where);
		$this->db->delete($table);
	}

}
