<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('MB');
		$this->load->library('template');
	}

	public function index()
	{
		if ($this->input->post('submit', TRUE) == 'Submit') {
			$user = $this->input->post('username', TRUE);
			$pass = $this->input->post('password', TRUE);

			$cek = $this->MB->get_where_login('user', array('username' => $user));
				if ($cek->num_rows() > 0) {
					$data = $cek->row(); 
					if (password_verify($pass, $data->password)) {
						$datauser = array(
							'admin' => $data->id,
							'user'  => $data->username,
							'level' => $data->level,
							'login' => TRUE
						);

						$this->session->set_userdata($datauser);
						redirect('dashboard');
					}else{
					$this->session->set_flashdata('alert','Password Salah Gan!!!');
					}
				}else{
					$this->session->set_flashdata('alert2', 'Anda Siapaaa ?');
				}
 			}
			if ($this->session->userdata('login') == TRUE) {
				redirect('dashboard');
			}
			$this->load->view('login');
	}

	public function signup()
	{
		if ($this->input->post('submit', TRUE) == 'Submit'){		
			$data['username'] = $this->input->post('username', TRUE);
			$pass 			  = $this->input->post('password', TRUE);
			$data['password'] = password_hash($pass, PASSWORD_DEFAULT, ['cost' => 10]);
			$data['level']    = 'user';

			$this->session->set_flashdata('daftar','<script>alert("akun berhasil di tambah");</script>');
			$this->MB->insert('user', $data);
			redirect('login');
		}

		$this->load->view('signup');
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}

}
