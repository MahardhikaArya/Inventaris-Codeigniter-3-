<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('MB');
		$this->load->library('template');
	}

	public function index()
	{
		// cek login
		$this->MB->cek();
		if ($this->session->userdata('level') == 'admin') {
			$data['user'] = $this->MB->get_user('user');	
			$this->template->admin('admin/User/user', $data);
		}else{
			print_r("*You don't have permission for this");
		}
	}

	public function add_user()
	{
		$data['username'] = $this->input->post('username', TRUE);
		$pass		  	  = $this->input->post('password', TRUE);
		$data['level']	  = $this->input->post('level', TRUE);
		$data['password'] = password_hash($pass, PASSWORD_DEFAULT, ['cost' => 10]);
			
		$this->MB->insert('user', $data);		
		echo json_encode(array("status" => TRUE));
	}

	public function update()
	{
		
	}

	public function delete()
	{

		$id = $this->uri->segment(3);
		$id = array('id' => $id);
		$this->MB->delete('user', $id);
		redirect('User');
	}

}
