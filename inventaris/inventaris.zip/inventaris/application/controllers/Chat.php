<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('MB');
		$this->load->library('template');
	}

	 public function index()
	{
		// cek login
		$this->MB->cek();
		$data['admin'] = $this->MB->get_admin('user');
		$this->template->admin('admin/User/admin', $data);
		
	}

	public function admin_message()
	{
		if ($this->input->post('submit', TRUE) == 'Submit') {
			$pesan = array(
				'pesan'   => $this->input->post('pesan', TRUE),
				'send_by' => $this->input->post('send_by', TRUE),
				'send_to' => $this->input->post('send_to', TRUE)
			);
			$this->session->set_flashdata('dadi', 'Pesan Berhasil dikirim');
			$this->MB->insert('pesan', $pesan);
			echo json_encode(array("status" => TRUE));
		}

		// proses send by
		$get = $this->MB->get_where('user', array('id' => $this->session->userdata('admin')))->row();
		$data['username'] = $get->id;

		// proses send by
		$get = $this->MB->get_where('user', array('id' => $this->session->userdata('admin')))->row();
		$data['send_by'] = $get->id;
		
		// Send to
		$id = $this->uri->segment(3);

		$data['send_to'] = $id;

		//balasan dari pertama
		$satu = array('send_to' => $this->session->userdata('admin'));
		$idp = array('send_by' =>$this->uri->segment(3));		
		$data['kedua'] = $this->MB->get_pesan('pesan', $satu, $idp);

		//tampil kedua
		$data['pertama'] =  $this->MB->get_where('pesan', array('send_to' => $id));

		$this->template->admin('admin/User/pesan',$data);
	}

	public function admin_reply()
	{
		if ($this->input->post('submit', TRUE) == 'Submit') {
			$pesan = array(
				'pesan'   => $this->input->post('pesan', TRUE),
				'send_by' => $this->input->post('send_by', TRUE),
				'send_to' => $this->input->post('send_to', TRUE)
			);
			$this->session->set_flashdata('dadi', 'Pesan Berhasil dikirim');
			$this->MB->insert('pesan', $pesan);
			echo json_encode(array("status" => TRUE));
		}	


		// proses send by
		$get = $this->MB->get_where('user', array('id' => $this->session->userdata('admin')))->row();
		$data['send_by'] = $get->id;
		
		// Send to
		$id = $this->uri->segment(3);

		$data['send_to'] = $id;

		//tampil pertama
		$data['pertama'] =  $this->MB->get_where('pesan', array('send_to' => $id));

		//balasan dari kedua
		$satu = array('send_to' => $this->session->userdata('admin'));
		$dua = array('send_to' => $id);
		$idp = array('send_by' =>$this->uri->segment(3));		
		$data['kedua'] = $this->MB->get_pesan('pesan', $satu, $idp);

		$this->template->admin('admin/User/admin_reply', $data);
	}

}
