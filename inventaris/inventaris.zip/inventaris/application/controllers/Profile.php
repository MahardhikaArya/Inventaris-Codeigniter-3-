<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('MB');
		$this->load->library('template');
	}

	public function index()
	{
		$this->MB->cek();		

		if ($this->input->post('submit', TRUE) == 'Submit') {
			$data = array(
				'nama' 			=> $this->input->post('nama', TRUE),
				'alamat' 		=> $this->input->post('alamat', TRUE),
				'tempat_lahir'  => $this->input->post('tempat_lahir', TRUE),
				'tanggal_lahir' => $this->input->post('tanggal_lahir', TRUE),
				'jenis_kelamin' => $this->input->post('jenis_kelamin', TRUE),
				'username' 		=> $this->input->post('username', TRUE),
				'deskripsi' 	=> $this->input->post('deskripsi', TRUE)
			);

			// Proses Update
			$this->MB->update('user', $data,  array('id' => $this->session->userdata('admin')));
			redirect('profile');
		}

		$get = $this->MB->get_where('user', array('id' => $this->session->userdata('admin')))->row();
			$data['nama'] 			= $get->nama;
			$data['alamat'] 		= $get->alamat;
			$data['tempat_lahir'] 	= $get->tempat_lahir;
			$data['tanggal_lahir']  = $get->tanggal_lahir;
			$data['jenis_kelamin']  = $get->jenis_kelamin;
			$data['username'] 		= $get->username;
			$data['level'] 			= $get->level;
			$data['deskripsi']		= $get->deskripsi;
		
		$this->template->admin('admin/profile', $data);
	}

}
