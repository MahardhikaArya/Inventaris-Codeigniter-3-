<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('MB');
		$this->load->library('template');
	}

	public function index()
	{
		$this->MB->cek();
		$data['barang'] = $this->MB->get_all('barang');
		$this->template->admin('admin/Barang/Barang', $data);
	}

	public function read_more()
	{
		$this->MB->cek();
		$id = $this->uri->segment(3);

		$id = $this->MB->get_where('barang', array('id' => $id));

		foreach ($id->result() as $key) {
			$data['id']		 	= $key->id;
			$data['nama']		= $key->nama;
			$data['gambar']	    = $key->gambar;
			$data['inventaris'] = $key->inventaris;			
			$data['letak'] 		= $key->letak;
			$data['merek'] 		= $key->merek;
			$data['asal']	 	= $key->asal;
			$data['status'] 	= $key->status;
			$data['bahan'] 		= $key->bahan;
			$data['satuan'] 	= $key->satuan;			
			$data['ukuran'] 	= $key->ukuran;			
			$data['tahun'] 		= $key->tahun;			
			$data['jumlah'] 	= $key->jumlah;	
			$data['harga'] 		= $key->harga;			
			$data['ket'] 		= $key->ket;					
		}
		$this->template->admin('admin/Barang/readmore_barang', $data);
	}

	public function update_barang()
	{
		$this->MB->cek();
		$id = $this->uri->segment(3);
		if ($this->input->post('submit', TRUE) == 'Submit'){
	
			$config['upload_path']	 = "./assets/upload";
			$config['allowed_types'] = "jpg|png|jpeg";
			$config['max_size']		 = "2048";
			$config['file_name'] 	 = "barang".time();
			
			$this->load->library('upload', $config);
			
			if ($this->upload->do_upload('gambar')) {
				
				$gbr = $this->upload->data();
				
				$data = array(
					'nama' 		 => $this->input->post('nama', TRUE),
					'gambar'	 => $gbr['file_name'],
					'inventaris' => $this->input->post('inventaris', TRUE),
					'letak' 	 => $this->input->post('letak', TRUE),
					'merek' 	 => $this->input->post('merek', TRUE),
					'asal' 		 => $this->input->post('asal', TRUE),
					'status' 	 => $this->input->post('status', TRUE),
					'bahan' 	 => $this->input->post('bahan', TRUE),
					'satuan' 	 => $this->input->post('satuan', TRUE),
					'ukuran' 	 => $this->input->post('ukuran', TRUE),
					'tahun' 	 => $this->input->post('tahun', TRUE),
					'jumlah' 	 => $this->input->post('jumlah', TRUE),
					'harga' 	 => $this->input->post('harga', TRUE),
					'ket' 		 => $this->input->post('ket', TRUE)
				);

				$id = $this->MB->update('barang', $data , array('id' => $id));
				redirect('barang');
			}
		}
		$data = $this->MB->get_where_barang('barang', array('id' => $id));
		foreach ($data as $key) {
				$data['nama'] 		= $key->nama;
				$data['gambar'] 	= $key->gambar;
				$data['inventaris'] = $key->inventaris;
				$data['letak']	    = $key->letak;
				$data['merek']		= $key->merek;
				$data['asal']		= $key->asal;
				$data['status']	    = $key->status;
				$data['bahan']	    = $key->bahan;
				$data['satuan']	    = $key->satuan;
				$data['ukuran']	    = $key->ukuran;
				$data['tahun']	    = $key->tahun;
				$data['jumlah']	    = $key->jumlah;
				$data['harga']	    = $key->harga;
				$data['ket']	    = $key->ket;
		}
		///////////////////////////////////////////////////////////////////
		$data['drop'] 	= $this->MB->get_all('inventaris');
		$data['drop1'] 	= $this->MB->get_all('letak');
		$data['drop2'] 	= $this->MB->get_all('status');		
		$data['drop3'] 	= $this->MB->get_all('merek');		
		$data['drop4'] 	= $this->MB->get_all('satuan');

		$data['header'] = "Update barang";
		$this->template->admin('admin/Barang/form_barang', $data);

	}	

	public function tambah_barang()
	{
		$this->MB->cek();
		$id = $this->uri->segment(3);
		if ($this->input->post('submit', TRUE) == 'Submit') {
			$config['upload_path']   = "./assets/upload";
			$config['allowed_types'] = "png|jpg|jpeg";
			$config['max_size']		 = "2048";
			$config['file_name']	 = "barang".time();

			$this->load->library('upload', $config); 
			if ($this->upload->do_upload('gambar')) {	
				$gbr = $this->upload->data();
				$barang = array(
					'nama' 		 => $this->input->post('nama', TRUE),
					'gambar'	 => $gbr['file_name'],
					'inventaris' => $this->input->post('inventaris', TRUE),
					'letak' 	 => $this->input->post('letak', TRUE),
					'merek' 	 => $this->input->post('merek', TRUE),
					'asal' 		 => $this->input->post('asal', TRUE),
					'status' 	 => $this->input->post('status', TRUE),
					'bahan' 	 => $this->input->post('bahan', TRUE),
					'satuan' 	 => $this->input->post('satuan', TRUE),
					'ukuran' 	 => $this->input->post('ukuran', TRUE),
					'tahun' 	 => $this->input->post('tahun', TRUE),
					'jumlah' 	 => $this->input->post('jumlah', TRUE),
					'harga' 	 => $this->input->post('harga', TRUE),
					'ket' 		 => $this->input->post('ket', TRUE)
					);
	
					$id = $this->MB->insert('barang', $barang);
					redirect('Barang');
				}else{
					$error = $this->upload->display_errors();
					print_r($error);
				}
		}
		$data['nama'] 		= $this->input->post('nama', TRUE);
		$data['gambar'] 	= $this->input->post('gambar', TRUE);
		$data['inventaris'] = $this->input->post('inventaris', TRUE);
		$data['letak']	    = $this->input->post('letak', TRUE);
		$data['merek']		= $this->input->post('merek', TRUE);
		$data['asal']		= $this->input->post('asal', TRUE);
		$data['status']	    = $this->input->post('status', TRUE);
		$data['bahan']	    = $this->input->post('bahan', TRUE);
		$data['satuan']	    = $this->input->post('satuan', TRUE);
		$data['ukuran']	    = $this->input->post('ukuran', TRUE);
		$data['tahun']	    = $this->input->post('tahun', TRUE);
		$data['jumlah']	    = $this->input->post('jumlah', TRUE);
		$data['harga']	    = $this->input->post('harga', TRUE);
		$data['ket']	    = $this->input->post('ket', TRUE);

		///////////////////////////////////////////////////////////
		
		$data['drop'] 	= $this->MB->get_all('inventaris');
		$data['drop1'] 	= $this->MB->get_all('letak');
		$data['drop2'] 	= $this->MB->get_all('status');		
		$data['drop3'] 	= $this->MB->get_all('merek');		
		$data['drop4'] 	= $this->MB->get_all('satuan');
		$data['header'] = "Tambah Barang";
		$this->template->admin('admin/Barang/form_barang', $data);
	}

	public function add_inventaris()
	{
		if ($this->input->post('inventaris', TRUE) == 'Inventaris') {
			$data['jenis'] = $this->input->post('jenis', TRUE);
			$this->MB->insert('inventaris', $data);
			echo json_encode(array('status' => TRUE));
		}
	}

	public function delete($id)
	{
		$this->MB->cek();
		$id = array('id' => $id);
		$this->MB->delete('barang', $id);
		redirect(base_url('barang'));
	}
}
