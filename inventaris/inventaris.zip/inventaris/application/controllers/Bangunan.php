<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bangunan extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('MB');
		$this->load->library('template');
	}

	public function index()
	{
		$this->MB->cek();
		$this->template->admin('admin/bangunan');
	}

}
